# 原神反和谐
*使用当前版本改文件方法反和谐;

*运行程序在弹出窗口选择原神安装目录,支持模糊匹配;

*匹配完成自动重命名对应目录,并且生成一个GenshinDebug.bat文件于桌面.此后若反和谐失效,双击GenshinDebug.bat即可;


*若不记得原神安装在哪个磁盘,支持各磁盘全盘搜索.

*代码参考如下;

*https://blog.csdn.net/abcjennifer/article/details/18147551

*https://blog.csdn.net/xdrt81y/article/details/14225113

*https://www.cnblogs.com/kire/p/4428821.html

*https://blog.csdn.net/guowenyan001/article/details/17259173
